﻿using System;
using System.Collections.Generic;
using System.Text;
using MvvmCross.Navigation;
using MvvmCross.ViewModels;
using MvvmCross.Commands;
namespace ColoringApp.Core.ViewModels
{
	public class CharacterListViewModel:MvxViewModel
	{

		private readonly IMvxNavigationService _navigationService;
		public CharacterListViewModel(IMvxNavigationService navigationService)
		{
			_navigationService = navigationService;

			ShowCharacterCommand = new MvxCommand(() => _navigationService.Navigate<CharacterViewModel>());
		}

		public IMvxCommand ShowCharacterCommand { get; private set; }
	}
}
